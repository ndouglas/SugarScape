import datetime, hashlib, json, os, pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parents[4]
out=pathlib.Path(__file__).resolve().parent
env=os.environ.copy()
env.update(CARGO_HOME="/tmp/sugarscape-minds-p4-20261007-vb9tv64o/cargo-home",CARGO_TARGET_DIR="/tmp/sugarscape-minds-p4-20261007-vb9tv64o/target",CARGO_NET_OFFLINE="true",npm_config_cache="/tmp/sugarscape-minds-p4-20261007-vb9tv64o/task5-npm-cache",WASM_PACK_CACHE="/tmp/sugarscape-minds-p4-20261007-vb9tv64o/task5-wasm-cache")
gates=[
("root-fmt",root,["cargo","fmt","--all","--","--check"]),
("survey-fmt",root,["cargo","fmt","--manifest-path","survey/Cargo.toml","--","--check"]),
("root-clippy",root,["cargo","clippy","--workspace","--all-targets","--locked","--","-D","warnings"]),
("survey-clippy",root,["cargo","clippy","--manifest-path","survey/Cargo.toml","--all-targets","--locked","--","-D","warnings"]),
("root-test",root,["cargo","test","--workspace","--locked"]),
("survey-test",root,["cargo","test","--manifest-path","survey/Cargo.toml","--locked"]),
("core-wasm",root,["cargo","build","-p","sugarscape-core","--target","wasm32-unknown-unknown","--locked"]),
("node-wasm",root,["wasm-pack","test","--node","crates/sugarscape-wasm"]),
("release-book",root,["cargo","test","-p","sugarscape-core","--release","--test","book","--","--ignored"]),
("web-build",root/"web",["npm","run","build"]),
("web-test",root/"web",["npm","test"]),
("release-boundary",root/"web",["npm","exec","--","vitest","run","src/determinism.test.ts","-t","protection checked WASM boundary|deception checked WASM boundary"]),
("default-boundary",root/"web",["env","-u","CARGO_TARGET_DIR","npm","exec","--","vitest","run","src/determinism.test.ts","-t","protection checked WASM boundary|deception checked WASM boundary"]),
]
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()
assert head=="0e24e3fe4fefcbf4d445c93dd004cd8a0a2c859a"
assert not (out/"integration-gates.jsonl").exists(), "No overwriting gate receipts"
for label,cwd,cmd in gates:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (out/"integration-gate-current.json").write_text(json.dumps(dict(label=label,command=cmd,start=start,head=head))+"\n")
 print("START",label,flush=True)
 logs={}
 with (out/("integration-"+label+".stdout.log")).open("wb") as stdout,(out/("integration-"+label+".stderr.log")).open("wb") as stderr:
  proc=subprocess.run(cmd,cwd=cwd,env=env,stdout=stdout,stderr=stderr)
 for stream in ["stdout","stderr"]:
  p=out/("integration-"+label+"."+stream+".log"); data=p.read_bytes(); logs[stream]=dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
 receipt=dict(label=label,command=cmd,cwd=str(cwd),head=head,start=start,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=proc.returncode,logs=logs,environment={k:env[k] for k in ["CARGO_HOME","CARGO_TARGET_DIR","CARGO_NET_OFFLINE","npm_config_cache","WASM_PACK_CACHE"]})
 with (out/"integration-gates.jsonl").open("a") as f: f.write(json.dumps(receipt)+"\n");f.flush();os.fsync(f.fileno())
 print("END",label,"exit",proc.returncode,flush=True)
 if proc.returncode: sys.exit(proc.returncode)
(out/"integration-gate-current.json").write_text(json.dumps(dict(status="complete",head=head))+"\n")
