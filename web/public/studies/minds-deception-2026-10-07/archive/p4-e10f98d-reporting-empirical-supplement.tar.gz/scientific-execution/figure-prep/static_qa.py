"""Inspect only the explicitly named synthetic preview exports."""
import csv
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image

root = Path('synthetic-preview-final')
chart = json.loads((root / 'chart-inputs.json').read_text())
assert chart['classification'] == 'synthetic_fixture'
assert [len(rows) for rows in chart['plots'].values()] == [32, 32, 32, 32]
assert sum(row['primary'] for rows in chart['plots'].values() for row in rows) == 64
assert all(sum(row['strata']['mirrored'] for row in rows) == 16 for rows in chart['plots'].values())
rows = list(csv.DictReader((root / 'chart-inputs.csv').open()))
assert len(rows) == 128 and sum(row['summary'] == 'null' for row in rows) == 2
inventory = json.loads((root / 'plot-inventory.json').read_text())
for item in inventory['files']:
    assert hashlib.sha256((root / item['path']).read_bytes()).hexdigest() == item['sha256']
for png in sorted(root.glob('*.png')):
    with Image.open(png) as image:
        image.verify()
    with Image.open(png) as image:
        assert image.size == (2400, 1280)
for svg in sorted(root.glob('*.svg')):
    tree = ET.parse(svg)
    texts = [''.join(element.itertext()) for element in tree.iter('{http://www.w3.org/2000/svg}text')]
    assert any('SYNTHETIC FIXTURE' in text for text in texts)
    assert any('Base orientation: all 16 strata' in text for text in texts)
    assert any('Reflected orientation: all 16 strata' in text for text in texts)
    labels = [text for text in texts if '/ cost ' in text]
    assert len(labels) == 32
result = dict(classification='static_synthetic_QA', plots=4, png_dimensions=[2400,1280],
              svg_xml_valid=True, svg_labels_per_plot=32, orientations_per_plot=2,
              estimates=128, primary=64, secondary=64, denominator=40, unavailable_rows=2,
              inventory_hashes_match=True,
              actual_measurement_results_read=False,
              manual_review='all four synthetic PNGs inspected through view_image; readable labels and separate orientations')
Path('static-qa.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
