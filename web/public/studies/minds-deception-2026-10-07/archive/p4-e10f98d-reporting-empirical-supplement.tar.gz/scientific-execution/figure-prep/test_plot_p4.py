"""Static DTO fixtures only: labels never construct a World or use an RNG."""
import copy
import csv
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import plot_p4

SEEDS = list(range(20001, 20041))


def synthetic_analysis():
    cells, endpoints, estimates = [], [], []
    for sender in ('ordinary', 'matched_neutral', 'sham'):
        for view in ('ambiguous', 'clear'):
            for seen in (False, True):
                for layout in ('on_route', 'off_route'):
                    for cost in (0.0, 3.0):
                        for mirrored in (False, True):
                            lab = dict(sender=sender, view=view, display_seen=seen,
                                       layout=layout, effort_cost=cost, mirrored=mirrored)
                            ident = '-'.join((sender.replace('_', '-'), view,
                                'seen' if seen else 'unseen', layout.replace('_', '-'),
                                f'cost{cost:g}', f'm{int(mirrored)}'))
                            cells.append(dict(condition=dict(id=ident, lab=lab), seeds=SEEDS.copy(),
                                biological_groups=['synthetic-group'] * 40,
                                completed_ticks=[64] * 40, wall_seconds=[0.0] * 40,
                                unavailable_lineage=[]))
                            for seed in SEEDS:
                                endpoints.append(dict(condition=ident, seed=seed,
                                    owner_ticks_alive=40, owner_alive=False,
                                    thief_transferred=0.0, lineage_unavailable_reason=None,
                                    elapsed_seconds=0.0, biological_group='synthetic-group',
                                    fingerprints=['synthetic'], cohorts=None))
                            if sender == 'sham':
                                for primary, baseline in ((True, 'matched-neutral'), (False, 'ordinary')):
                                    for metric in ('owner_ticks_alive', 'thief_transferred'):
                                        # Hand-selected summaries, never inferred from a campaign.
                                        mean = 0.0 if cost == 0 else (-2.0 if metric == 'thief_transferred' else 1.0)
                                        estimates.append(dict(id=f'{ident} minus {baseline}{ident[4:]}',
                                            metric=metric, primary=primary, denominator=40,
                                            summary=dict(n=40, mean=mean, ci95=[mean, mean],
                                                positive=40 if mean > 0 else 0,
                                                zero=40 if mean == 0 else 0,
                                                negative=40 if mean < 0 else 0), unavailable=[]))
    return dict(schema='minds-deception-measured-v1', fixture_classification='synthetic_fixture',
        census=dict(planned=3840, attempted=3840, complete=3840, failed=0, invalid=0,
                    partial=0, pending=0, unstarted=0, unavailable_lineage=0),
        cells=cells, endpoints=endpoints, estimates=estimates,
        biological_groups=[dict(id='synthetic-group', members=['synthetic fixture'], frames=[])],
        repeated_endpoints=[dict(members=['synthetic duplicate'])],
        effective_aliases=[dict(members=['synthetic alias'])])


def unavailable_fixture():
    data = synthetic_analysis()
    condition = 'sham-ambiguous-unseen-on-route-cost0-m0'
    reason = 'synthetic lineage deliberately unavailable'
    entry = dict(seed=20001, reason=reason)
    for endpoint in data['endpoints']:
        if endpoint['condition'] == condition and endpoint['seed'] == 20001:
            endpoint.update(thief_transferred=None, lineage_unavailable_reason=reason)
    for cell in data['cells']:
        if cell['condition']['id'] == condition:
            cell['unavailable_lineage'] = [entry]
    for estimate in data['estimates']:
        if estimate['id'].startswith(condition + ' minus ') and estimate['metric'] == 'thief_transferred':
            estimate.update(summary=None, unavailable=[dict(seed=20001, reason=f'{condition}: {reason}')])
    data['census']['unavailable_lineage'] = 1
    return data


class CoverageTests(unittest.TestCase):
    def test_retains_128_estimates_with_32_per_plot(self):
        chart = plot_p4.chart_inputs(synthetic_analysis(), '0' * 64, synthetic=True)
        self.assertIsInstance(chart, dict)
        self.assertEqual([len(rows) for rows in chart['plots'].values()], [32, 32, 32, 32])
        self.assertEqual(sum(r['primary'] for rows in chart['plots'].values() for r in rows), 64)

    def test_keeps_both_orientations_and_negative_zero_positive_rows(self):
        chart = plot_p4.chart_inputs(synthetic_analysis(), '0' * 64, synthetic=True)
        for rows in chart['plots'].values():
            self.assertEqual(sum(row['strata']['mirrored'] for row in rows), 16)
        means = [row['summary']['mean'] for rows in chart['plots'].values() for row in rows]
        self.assertEqual((min(means), max(means), means.count(0.0)), (-2.0, 1.0, 64))

    def test_preserves_nonzero_interval_exactly(self):
        data = synthetic_analysis()
        data['estimates'][0]['summary']['ci95'] = [-0.125, 0.375]
        chart = plot_p4.chart_inputs(data, '0' * 64, synthetic=True)
        row = next(row for rows in chart['plots'].values() for row in rows
                   if row['id'] == data['estimates'][0]['id'] and row['metric'] == 'owner_ticks_alive')
        self.assertEqual(row['summary']['ci95'], [-0.125, 0.375])

    def test_rejects_incomplete_census(self):
        data = synthetic_analysis()
        data['census'].update(complete=3839, pending=1)
        with self.assertRaisesRegex(ValueError, 'census'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_rejects_missing_estimate(self):
        data = synthetic_analysis()
        data['estimates'].pop()
        with self.assertRaisesRegex(ValueError, '128'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_rejects_duplicate_estimate(self):
        data = synthetic_analysis()
        data['estimates'][-1] = copy.deepcopy(data['estimates'][0])
        with self.assertRaisesRegex(ValueError, 'estimate coverage'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_rejects_survivor_subset_denominator(self):
        data = synthetic_analysis()
        data['estimates'][0]['denominator'] = 39
        with self.assertRaisesRegex(ValueError, 'denominator'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_rejects_missing_registered_seed(self):
        data = synthetic_analysis()
        data['cells'][0]['seeds'][-1] = 99999
        with self.assertRaisesRegex(ValueError, 'seed'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_rejects_missing_endpoint(self):
        data = synthetic_analysis()
        data['endpoints'].pop()
        with self.assertRaisesRegex(ValueError, 'endpoint coverage'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_rejects_nonfinite_summary(self):
        data = synthetic_analysis()
        data['estimates'][0]['summary']['mean'] = float('nan')
        with self.assertRaisesRegex(ValueError, 'finite'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_unavailable_food_keeps_denominator_reason_and_null(self):
        chart = plot_p4.chart_inputs(unavailable_fixture(), '0' * 64, synthetic=True)
        self.assertIsInstance(chart, dict)
        rows = [r for rows in chart['plots'].values() for r in rows if r['summary'] is None]
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]['denominator'], 40)
        self.assertEqual(rows[0]['unavailable'][0]['seed'], 20001)
        self.assertIn('synthetic lineage', rows[0]['unavailable'][0]['reason'])

    def test_rejects_unavailable_food_replaced_by_zero(self):
        data = unavailable_fixture()
        for estimate in data['estimates']:
            if estimate['summary'] is None:
                estimate['summary'] = dict(n=40, mean=0, ci95=[0, 0], positive=0, zero=40, negative=0)
        with self.assertRaisesRegex(ValueError, 'unavailable'):
            plot_p4.chart_inputs(data, '0' * 64, synthetic=True)

    def test_synthetic_and_completed_modes_cannot_be_mislabelled(self):
        with self.assertRaisesRegex(ValueError, 'synthetic'):
            plot_p4.chart_inputs(synthetic_analysis(), '0' * 64, synthetic=False)

    def test_export_creates_four_png_svg_pairs_and_exact_hashed_inputs(self):
        source = json.dumps(unavailable_fixture(), allow_nan=False).encode()
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary) / 'figures'
            result = plot_p4.export(source, destination, synthetic=True)
            self.assertIsInstance(result, dict)
            self.assertEqual(len(list(destination.glob('*.png'))), 4)
            self.assertEqual(len(list(destination.glob('*.svg'))), 4)
            for path in destination.glob('*.png'):
                self.assertTrue(path.read_bytes().startswith(b'\x89PNG\r\n\x1a\n'))
            inventory = json.loads((destination / 'plot-inventory.json').read_text())
            for item in inventory['files']:
                self.assertEqual(hashlib.sha256((destination / item['path']).read_bytes()).hexdigest(), item['sha256'])
            chart = json.loads((destination / 'chart-inputs.json').read_text())
            self.assertEqual(chart['analysis_sha256'], hashlib.sha256(source).hexdigest())
            self.assertEqual(chart['diagnostics']['effective_aliases'], [dict(members=['synthetic alias'])])
            with (destination / 'chart-inputs.csv').open() as stream:
                rows = list(csv.DictReader(stream))
            self.assertEqual(len(rows), 128)
            self.assertEqual(sum(row['summary'] == 'null' for row in rows), 2)
            with self.assertRaises(FileExistsError):
                plot_p4.export(source, destination, synthetic=True)


if __name__ == '__main__':
    unittest.main()
