# P4 artifact preparation — static synthetic inputs only

Preparation is complete; actual measurement analysis, actual scientific figures, empirical review, reporting integration, publication and final archival are still controller-owned later steps. This preparation neither reads partial campaign outcomes nor supplies acceptance for any subsequent action.

All created files live in:

`/private/tmp/sugarscape-minds-p4-20261007-vb9tv64o/checkout/.superpowers/sdd/2026-10-07-minds-deception/scientific-execution/figure-prep/`

Source HEAD remained `e10f98d99586d94f5adc8eab1f95b80e5c5b1865`. Scoped tracked and staged diffs for `crates`, `survey/src`, `docs`, `.github`, and `web` were empty (exit 0). No core/protocol/frozen-source/packet/campaign data, user checkout, public destination, or commit was changed. No helper/reviewer was dispatched. No World, RNG, scientific CLI, campaign runner, or paired-estimate calculation was invoked.

## Binding and source inspection

Read actual acceptance at `../prospective-acceptance.json`: ACCEPTED by `/root/p4_prospective_scientific_reviewer`, recorded 2026-10-08T06:19:18.616234+00:00. Review SHA256 `800226cf5b23a51c1aaca1282be793ba63cb1de83ff7587cfee88ef4a2523966`; source e10f98d; binary `38f7137b7b92521b8e5d82c43b883c1f7dc92f9151112c73665913299c54caa4`; protocol `7e0b9a7fb6973a3ba95fad70ddf911105f753a73b7fe45a8ab5040e3d6901d4d`; manifest `cd4996a57ccc216dac634994817796c16a0cc6dc45f48b4e903073b3700ee2be`. Its recorded NOT_STARTED status describes the earlier acceptance record; this agent did not inspect campaign progress or update that record.

Read the prospective gate brief and approved Task 5 Step 6, then static `survey/src/claims/deception_report.rs`, `deception.rs`, `deception_archive.rs` Census definition, `survey/src/stats.rs` PairedSummary definition, and `crates/sugarscape-core/src/minds/deception/{state,lab,mod}.rs`. Inspected existing plotting/publication Python scripts, Pages/Vite/package metadata, repository indexes, and dated report layout for conventions. No P4 campaign output, partial result, or campaign analysis was opened.

The typed Analysis retains 96 cell records, 3,840 endpoints, 128 Estimate objects, full biological groups/frames, repeated endpoint vectors and effective aliases. Estimate summaries already contain paired Student-t 95% intervals and signs. The exporter preserves those summaries; it does not re-estimate their means, intervals, signs or statistics. Biological archive validation and exact saved-data reanalysis remain mandatory upstream checks, not something this plotting script substitutes for.

## Created artifacts

- `plot_p4.py`: standalone Matplotlib Agg exporter for already saved typed Analysis bytes. Requires an explicit `--synthetic` or later `--completed-authorized` mode and a fresh output directory; never overwrites a destination. Actual mode is a caller attestation, not manufactured scientific acceptance or automatic measurement authorization.
- `test_plot_p4.py`: 14 unittest cases and static DTO fixture builders. Registered-looking seed labels are static identifiers; no simulation/RNG imports or calls. Fixture endpoint and summary values are deliberately hand-selected and are not a biologically validated archive or study result.
- `verify_command.py`, `static-verification.jsonl`: exact explicitly executed static command argv, working directory, UTC time, exits, stdout and stderr, including failed/red attempts.
- `static_qa.py`, `static-qa.json`: PNG decoding/dimension checks, SVG XML/text/32-row label checks, complete exported-row counts, orientation separation, unavailable rows and exact inventory hash checks.
- `plotting-environment.json`: existing general Homebrew Python/library identity. Python 3.13.5 `/opt/homebrew/opt/python@3.13/bin/python3.13`; Matplotlib 3.10.9; NumPy 2.4.6; SciPy 1.17.1; Pillow 12.2.0. SciPy/Pillow are available general libraries; inference does not use SciPy. Owned `matplotlib-cache/` is forced by the exporter. No retained P3/DP environment or executable was reused or rebuilt; no new install was needed.
- `synthetic-analysis.json`: explicitly tagged synthetic DTO fixture with one deliberately unavailable endpoint, producing two unavailable food contrasts. SHA256 `46b9f4d236d4f5381b363c5a37302fed988204b0bc0bbcc84d6ae9599e6479d4`.
- `synthetic-preview/`: first synthetic render, retained as preparation history.
- `synthetic-preview-final/`: final synthetic render after owning the cache unconditionally and improving the unavailable text background. Four PNG and four SVG assets; `chart-inputs.json`, `chart-inputs.csv`, `plot-inventory.json`.
- `artifact-preparation-report.md`: this report, including destination guidance and remaining gates.
- `figure-prep-inventory.json`: final owned artifact hashes (generated after verification receipts stop changing). Interpreter bytecode and Matplotlib cache are incidental owned tooling files, excluded from this reporting inventory.

None of the synthetic input/preview files belongs in a measured-results publication.

## Coverage and semantics

The exact four plot names are `01-primary-food`, `02-primary-lifetime`, `03-secondary-food`, `04-secondary-lifetime`. Each has 32 strata, shown as separate base/reflected panels of 16. The two primary plots retain all 64 Sham-minus-MatchedNeutral estimates; the two secondary plots retain all 64 separately secondary Sham-minus-Ordinary estimates. No pooling, favorable selection, significance test, multiplicity claim, interaction estimate, or overall Holds/Fails verdict is created.

Before export the script checks complete planned/attempted/complete census 3,840 with all failed/invalid/partial/pending/unstarted counts zero; all 96 canonical exact configurations; each cell's exact labels 20001–20040 and 64-tick horizons; all 3,840 unique endpoint keys; all 128 unique registered contrast/metric/family keys; n=40 denominators and available-summary n/sign totals; finite ordered intervals; cell/endpoint/census unavailable lineage agreement; and exact paired unavailable seeds and reasons. One unavailable food lineage causes the full contrast summary to remain null, with n=40 retained, instead of a survivor subset or zero.

PNG exports are 2,400×1,280 at 160 DPI. SVG keeps editable text. Every interval, mean, sign and unavailable record is preserved without rounding in chart JSON/CSV. Chart JSON retains cell/alias/duplicate diagnostics and identifies full biological frames/endpoint lineage in the exact bound source analysis. Inventory includes JSON/CSV/PNG/SVG byte lengths and SHA256s, source-analysis and source-script hashes, Python/Matplotlib/NumPy/backend/font hash, DPI and SVG hash salt. The inventory does not hash itself; the enclosing evidence manifest must do that.

## Static verification and failed attempts

All substantive static verification commands, exits and full output are in `static-verification.jsonl`.

- Initial intended red run: exit 1, 11 expected missing-implementation failures plus one test ordering error (the assertion checked chart shape after indexing a placeholder None). Moved that assertion first, then reran: exit 1, all 12 tests failed for missing behavior as intended.
- First implemented run: exit 1, 3 failures/2 errors after the wrong-seed rejection test mutated the fixture's shared SEEDS list. Root cause was fixture reuse, not exporter permissiveness. Changed each cell to own `SEEDS.copy()`; next run exit 0, all 12 passed. One focused fix attempt.
- Added two preservation checks for both 16-row orientations/negative-zero-positive retention and exact nonzero supplied interval preservation. Full owned discovery run: exit 0, all 14 passed. These additional checks confirmed existing behavior.
- Final full owned discovery after the cache/text changes: `python3 -m unittest discover -v -p 'test_*.py'`, exit 0, 14 passed.
- `python3 -m py_compile plot_p4.py test_plot_p4.py verify_command.py static_qa.py`: exit 0.
- Synthetic fixture generation and both fresh synthetic export commands: exit 0. Final `python3 plot_p4.py --synthetic --analysis synthetic-analysis.json --out synthetic-preview-final`: four plots, 128 estimates, fixture classification.
- `python3 static_qa.py`: exit 0; four PNGs decoded, four SVGs parsed, 32 labels per SVG, all 128 rows, 64+64 families, two unavailable rows, exact hashes.
- All four initial PNGs visually inspected through view_image; final primary-lifetime image inspected again. Labels, separate orientations, synthetic titles, zero-width interval points and unavailable rows are readable. SVG text verification confirms titles and all labels; actual measured plot visual inspection remains a future separate step.
- An initial git scope check used one too many parent-directory segments and returned 129, "Not a git repository". Repeated with the explicit checkout path: unstaged/staged scoped diff exit 0; HEAD command exit 0, e10f98d.

Early read-only discovery commands also reported missing guessed top-level `scripts`, `src`, `scientific-execution`, `tools`, `bin`, `Makefile`, `docs/SUMMARY.md`, `docs/minds.md`, and `web/scripts/*` locations. Correct existing paths were then used. These were path discovery mistakes, not study commands. No issue required three failed repair attempts. No Rust/native/WASM suite was rerun: the only new code is this owned Python exporter, and this task explicitly prohibited World/RNG invocation.

## Reporting and publication destinations — guidance only

Use existing dated findings/evidence conventions, with a controller-confirmed P4 slug before future writes. Proposed logical destinations:

- `docs/superpowers/specs/2026-10-07-minds-deception-findings.md`: actual reviewed interpretation, keeping registration date and actual execution/report UTC dates distinct.
- `docs/superpowers/specs/2026-10-07-minds-deception-provenance.json`: actual measurement/reanalysis/artifact identities and immutable evidence references, independent prospective and empirical reviews included with their exact scopes.
- `docs/superpowers/specs/2026-10-07-minds-deception-publication.md`: later published remote SHA, matching CI/Pages run identities, stable served URLs and actual downloaded hashes. Do not claim published status before those checks.
- `survey/out/minds-deception-2026-10-07/`: reviewed reporting packet location, if the controller confirms this slug. Copy exact actual `analysis.json`, `results.md`, four PNG/SVG pairs, chart JSON/CSV, figure inventory and provenance/evidence manifest without regenerating inference. Existing full raw archive may remain a separate immutable archive.
- Update relevant links/status in `docs/studies/2026-09-27-minds.md`, `docs/roadmap.md`, `docs/papers.md`, and `docs/reproducibility.md`, preserving historical text and the unconfirmed 1998 citation lead. P4 remains a supplied construction experiment, not a confirmed animal reproduction.
- Stage only reviewed compact report/figures/chart-inputs/results/evidence-manifest files under `web/public/studies/minds-deception-2026-10-07/` (or the controller's confirmed slug). Vite copies public assets into `web/dist/studies/<slug>/`; `.github/workflows/pages.yml` deploys `web/dist`. Adding `docs/` or `survey/out/` alone does not serve those bytes. This narrow asset path needs no Vite/layout redesign. No repository copy-papers hook was found; source paper directories are ignored and should not be mistaken for a P4 publication mechanism.
- Preserve raw attempts/frames/outcomes, exact source archive, protocol/manifest/binary/build and toolchain evidence, review receipts, reanalysis, actual plots, preparation tools and CI/Pages/served checks outside temporary worktrees under a controller-owned immutable archive, following the existing `~/.local/share/sugarscape/evidence/<study-slug>/` convention. If too large for Pages, link an appropriate publicly accessible immutable external archive and retain exact file inventories/hashes; a local filesystem path alone is not a public reproducibility link.

The final human report must separate: false observer estimate; actual diversion/target inspection; physical original food first transferred; owner ticks alive. Preserve exact cost/paid/unpaid/body-occupancy/recovery/effort/zero-extra-distance explanations and all clear/unseen/truthful/expired/death/unreachable controls actually relevant in the retained frames. Describe ordinary-reference cost aliases separately from matched physical controls. Report repeated endpoints/effective aliases and full biological groups without claiming seed independence. Retain horizon, unreplenished fixture, supplied cue/no-learning, denominator and unavailable-lineage limitations. Do not infer theft or lifetime advantage from a false belief/diversion alone, require favorable effects, or collapse all outcomes into a verdict.

## Remaining controller-owned steps

1. Complete all registered attempts under the authorized sole writer; verify census and strict saved-data validation/reanalysis. Do not repair this by retry, resume, seed replacement, partial pairing or rerunning studies.
2. Supply the exact complete actual analysis and separately authorize actual figure/report work. Only then run `python3 plot_p4.py --completed-authorized --analysis /EXACT/COMPLETE/analysis.json --out /NEW/ACTUAL/figures`. Do not pass the synthetic fixture to this mode. This script reads saved JSON only and never invokes the scientific executable.
3. Inspect actual four PNG/SVG pairs and exact inputs/hashes, write actual findings and provenance, and obtain fresh independent empirical review of complete evidence. Plot export success cannot supply empirical approval.
4. Stage only the reviewed actual packet/report/compact Pages assets, perform reviewed local-main integration and normal push per the approved plan, and verify actual remote head with matching CI/Pages. No PR or broad build-layout changes are implied.
5. Compare each emitted `web/dist/studies/<slug>/<file>` SHA256 against the reviewed evidence manifest, then fetch the actual deployed URLs after publication and verify downloaded lengths/hashes. Include chart JSON/CSV, results/report, inventory/evidence manifest, and all eight PNG/SVG assets; verify image content as well as HTTP success. Preserve deployment/served receipts separately from measured source identities.
6. Hash-verify final external archives and exact public links before any owned cleanup. Preserve historical P3/DP evidence and scientific identities without relabeling, rerunning, or rebuilding retained environments.

Concerns: this exporter validates the typed Analysis coverage and unavailable representation, not raw scientific biological validity; upstream analysis/reanalysis must establish that. Actual data/renders/report/empirical review/publication/archive have deliberately not been completed in this preparation-only task. General plotting versions are recorded, not replacements for the frozen scientific runtime. Actual mode still requires a real controller authorization; its CLI flag is not an independent review or gate.
